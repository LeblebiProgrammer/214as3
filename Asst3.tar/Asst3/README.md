This program is capable of receiveing multiple connections and handling their  create, destroy, checkout methods. On the client side, both add and remove have been implemented. However, thread syncronization wasnt implemented.


